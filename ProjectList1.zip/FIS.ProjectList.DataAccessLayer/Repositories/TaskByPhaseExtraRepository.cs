﻿using FIS.ProjectList.DataAccessLayer.Interfaces;
using FIS.ProjectList.DataLayer;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FIS.ProjectList.DataAccessLayer.Repositories
{
    public class TaskByPhaseExtraRepository : BaseRepository<TaskByPhaseExtra>, ITaskByPhaseExtraRepository
    {
        public TaskByPhaseExtraRepository(DbContext dbContext) 
            : base(dbContext){

        }
    }
}
