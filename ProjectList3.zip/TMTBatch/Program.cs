﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMTBatch
{
    class Program
    {
        private static string connectionStr = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseConnection"].ToString();
        private static StringBuilder sb = new StringBuilder();
        static void Main(string[] args)
        {
            string tableStyle = @"<style> table { border-collapse: collapse; } table, td, th { border: 1px solid black; } th { background-color: #e5e5e5; } h4 { text-decoration: underline; } </style>";
            sb.Append(tableStyle);
            CommentAlerts();
            TaskAlerts();
            StatusReportAlerts();

            string subject = ConfigurationManager.AppSettings["EmailSubject"] + "Alert/Task/Status Report - Notifications";
            Email.Send(ConfigurationManager.AppSettings["FromEmail"], ConfigurationManager.AppSettings["ToEmail"], subject, sb.ToString());

            UpdateAlertSent();

        }

        private static void UpdateAlertSent()
        {
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "UpdateAlertSent";

                    command.ExecuteNonQuery();
                }
                connection.Close();
            }
        }

        private static void StatusReportAlerts()
        {
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                DataSet dataSet = new DataSet();

                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "GetStatusReportForAlerts";

                        dataAdapter.SelectCommand = command;

                        dataAdapter.Fill(dataSet, "TableName");
                        sb.Append("<h4>Prior Week's Status Updates:</h4>");
                        sb.Append("<table>");
                        sb.Append("<tr>");
                        sb.Append("<th>");
                        sb.Append("Task#");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Desc");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Status");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Updated By");
                        sb.Append("</th>");
                        sb.Append("</tr>");
                        foreach (DataRow dr in dataSet.Tables[0].Rows)
                        {
                            sb.Append("<tr>");
                            sb.Append("<td>");
                            sb.Append(dr["Task"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["Desc"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["Status"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["FirstName"]);
                            sb.Append("</td>");
                            sb.Append("</tr>");
                        }
                        sb.Append("</table>");
                    }

                    dataSet.Dispose();
                    connection.Close();
                }
            }
        }

        private static void CommentAlerts()
        {

            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                DataSet dataSet = new DataSet();

                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "GetTodaysAlerts";

                        dataAdapter.SelectCommand = command;

                        dataAdapter.Fill(dataSet, "TableName");
                        sb.Append("<h4>Alert Notifications:</h4>");
                        sb.Append("<table>");
                        sb.Append("<tr>");
                        sb.Append("<th>");
                        sb.Append("Task#");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Sent By");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Alert Description");
                        sb.Append("</th>");
                        sb.Append("</tr>");
                        foreach (DataRow dr in dataSet.Tables[0].Rows)
                        {
                            sb.Append("<tr>");
                            sb.Append("<td>");
                            sb.Append(dr["Task"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["FirstName"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["AlertMessage"]);
                            sb.Append("</td>");
                            sb.Append("</tr>");
                        }
                        sb.Append("</table>");
                    }

                    dataSet.Dispose();
                    connection.Close();
                }
            }
        }

        private static void TaskAlerts()
        {
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                DataSet dataSet = new DataSet();

                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "GetTodaysTasks";

                        dataAdapter.SelectCommand = command;

                        dataAdapter.Fill(dataSet, "TableName");

                        sb.Append("<h4>Task Updates:</h4>");
                        sb.Append("<table>");
                        sb.Append("<tr>");
                        sb.Append("<th>");
                        sb.Append("Task#");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Desc");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("Status");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("CreatedDate");
                        sb.Append("</th>");
                        sb.Append("<th>");
                        sb.Append("UpdatedBy");
                        sb.Append("</th>");
                        sb.Append("</tr>");
                        foreach (DataRow dr in dataSet.Tables[0].Rows)
                        {
                            sb.Append("<tr>");
                            sb.Append("<td>");
                            sb.Append(dr["Task"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["Desc"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["Status"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["CreatedDate"]);
                            sb.Append("</td>");
                            sb.Append("<td>");
                            sb.Append(dr["UpdatedBy"]);
                            sb.Append("</td>");
                            sb.Append("</tr>");
                        }
                        sb.Append("</table>");
                    }

                    dataSet.Dispose();
                    connection.Close();

                    //Email.Send("TMT@fisglobal.com", "naresh.metuku@fisglobal.com", "TMT - Alert/Task - Notifications", sb.ToString());
                }
            }
        }
    }
}
