﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReleaseBatch.SMTP;
using System.Collections;

namespace ReleaseBatch
{
    class Program
    {
        
        private static string connectionStr = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseConnection"].ToString();
        private static StringBuilder sb = new StringBuilder();
        private static StringBuilder mailIds = new StringBuilder();
        private static ArrayList list = new ArrayList();
        private static void Main(string[] args) 
        {
            
            string tableStyle = @"<style> table { border-collapse: collapse; } table, td, th { border: 1px solid black; } th { background-color: #e5e5e5; } h4 { text-decoration: underline; } </style>";
            sb.Append(tableStyle);

            ReleaseStatusAlerts();

            string subject = ConfigurationManager.AppSettings["EmailSubject"] + " Release reminder– UAT Signoff, Gates ID and Release  Notes";
            string toemail = ConfigurationManager.AppSettings["ToEmail"];

            // Email
            SMTPWebService smtp = new SMTPWebService();           
            string from = ConfigurationManager.AppSettings["FromEmail"].ToString();
            if (list.Count > 0)
            {
                foreach (string str in list)
                {
                    mailIds.Append(str + ";");
                }
                mailIds.Append(toemail);                
                smtp.SMTPSendHTML(from, mailIds.ToString(), subject, sb.ToString());
            }
            else
            {
                StringBuilder sbnodates = new StringBuilder();
                sbnodates.Append("<h4><U>Action Items:</U></h4>");
                sbnodates.Append("<h5>BA: Obtain UAT Signoff and submit change request</h5>");
                sbnodates.Append("<h5>Dev/Tech Lead: Submit Gates ID request and send release notes to BA</h5>");
                sbnodates.Append("<h3>No Tasks are available</h3>");

                smtp.SMTPSendHTML(from, toemail, subject, sbnodates.ToString());
            }
            
        }

        

        private static void ReleaseStatusAlerts()
        {
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                DataSet dataSet = new DataSet();
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "GetReleaseInformation";

                        dataAdapter.SelectCommand = command;

                        dataAdapter.Fill(dataSet, "TableName");                       
                        if (dataSet.Tables[0].Rows.Count > 0)
                        {
                            sb.Append("<h4><U>Action Items:</U></h4>");
                            sb.Append("<h5>BA: Obtain UAT Signoff and submit change request</h5>");
                            sb.Append("<h5>Dev/Tech Lead: Submit Gates ID request and send release notes to BA</h5>");
                            sb.Append("<table>");
                            sb.Append("<tr>");
                            sb.Append("<th width='10%'>");
                            sb.Append("Task#");
                            sb.Append("</th>");
                            sb.Append("<th width='55%'>");
                            sb.Append("Desc");
                            sb.Append("</th>");
                            sb.Append("<th width='10%'>");
                            sb.Append("Product Date");
                            sb.Append("</th>");
                            sb.Append("<th width='10%'>");
                            sb.Append("Current Phase");
                            sb.Append("</th>");
                            sb.Append("<th width='15%'>");
                            sb.Append("List of Apps");
                            sb.Append("</th>");
                            sb.Append("</tr>");
                            foreach (DataRow dr in dataSet.Tables[0].Rows)
                            {
                                sb.Append("<tr>");
                                sb.Append("<td>");
                                sb.Append(dr["Task#"]);
                                sb.Append("</td>");
                                sb.Append("<td>");
                                sb.Append(dr["Desc"]);
                                sb.Append("</td>");
                                sb.Append("<td>");
                                sb.Append(dr["ProductDate"]);
                                sb.Append("</td>");
                                sb.Append("<td>");
                                sb.Append(dr["CurrentPhase"]);
                                sb.Append("</td>");
                                sb.Append("<td>");
                                sb.Append(dr["ListOfApps"]);
                                sb.Append("</td>");
                                sb.Append("</tr>");
                                mailIds.Append(dr["EmailIds"].ToString());
                                string[] ids = mailIds.ToString().Split(',');
                                foreach (string str in ids)
                                {
                                    if (!String.IsNullOrEmpty(str))
                                    {
                                        if (!list.Contains(str))
                                        {
                                            list.Add(str);
                                        }
                                    }
                                }
                                mailIds.Clear();
                            }
                            sb.Append("</table>");
                        }
                    }
                   
                    dataSet.Dispose();
                    connection.Close();
                }
            }
        }       
    }
}
