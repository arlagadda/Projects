﻿
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ReportBatch.SMTP;
using System.Net.Mail;
using System.Net;
using System.IO;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Extensions1;


namespace ReportBatch
{
    class Program
    {
        private static string connectionStr = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseConnection"].ToString();
        private static StringBuilder sb = new StringBuilder();        

        static void Main(string[] args)
        {
            ReportAlerts();

            // Email
            SMTPWebService smtp = new SMTPWebService();
            string from = ConfigurationManager.AppSettings["FromEmail"].ToString();
            string to = ConfigurationManager.AppSettings["ToEmail"].ToString();
            string subject = "Midrange Credit - Dev & QA - Weekly meeting - Task List";

            byte[] buff = File.ReadAllBytes(AppDomain.CurrentDomain.BaseDirectory + "MidrangeTaskList-QA_Meeting.xls");

            smtp.SMTPSendWithAttachment(from, to, subject, "Attached is the list of Midrange task:", "", buff, "MidrangeTaskList-QA_Meeting.xls");

            File.Delete(AppDomain.CurrentDomain.BaseDirectory + "MidrangeTaskList-QA_Meeting.xls");

        }

        private static void ReportAlerts()
        {
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                DataSet dataSet = new DataSet();
                StringBuilder mailIds = new StringBuilder();
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "spGetQAReport";
                        string data = String.Empty;
                        dataAdapter.SelectCommand = command;

                        dataAdapter.Fill(dataSet, "TableName");
                        dataSet.Tables[0].Columns.RemoveAt(4);


                        //Write to the spreadsheet
                        MemoryStream stream = SpreadsheetReader.Create();
                        SpreadsheetDocument doc = SpreadsheetDocument.Open(stream, true);                       
                        WorksheetPart worksheetPart = SpreadsheetReader.GetWorksheetCreatedByName(doc, "Sheet1", "QAReport");
                        WorksheetWriter writer = new WorksheetWriter(doc, worksheetPart);
                        SpreadsheetStyle style = SpreadsheetReader.GetDefaultStyle(doc);
                        style.IsBold = true;
                                              

                        for (int j = 0; j <= dataSet.Tables[0].Columns.Count - 1; j++)
                        {
                            
                            data = dataSet.Tables[0].Columns[j].Caption.ToString();

                            string column = DocumentFormat.OpenXml.Extensions1.WorksheetWriter.GetCellReference(1, j);
                            if (dataSet.Tables[0].Columns[j].Caption == "PPL#/I#/R#")
                            {
                                data = "TaskID";
                            }
                            else if (dataSet.Tables[0].Columns[j].Caption == "PPL#/I#/R#" ||
                                dataSet.Tables[0].Columns[j].Caption == "TaskPhase" ||
                                dataSet.Tables[0].Columns[j].Caption == "CodeChange")
                            {
                                 writer.FindColumn(column.Remove(1)).Width = 12;
                            }
                            else if (dataSet.Tables[0].Columns[j].Caption.Contains("App"))
                            {
                                writer.FindColumn(column.Remove(1)).Width = 15;                                                          
                            }
                            else if (dataSet.Tables[0].Columns[j].Caption == "Description")
                            {
                                writer.FindColumn(column.Remove(1)).Width = 50;                                  
                            }

                            writer.PasteText(column, data, style);
                        }

                        for (int j = 0; j <= dataSet.Tables[0].Columns.Count - 1; j++)
                        {
                            for (int i = 0; i <= dataSet.Tables[0].Rows.Count - 1; i++)
                            {
                                data = dataSet.Tables[0].Rows[i].ItemArray[j].ToString();

                                string column = DocumentFormat.OpenXml.Extensions1.WorksheetWriter.GetCellReference(i + 2, j);                                
                                if ((dataSet.Tables[0].Columns[j].Caption == "Design" ||
                                    dataSet.Tables[0].Columns[j].Caption == "Dev" ||
                                    dataSet.Tables[0].Columns[j].Caption == "SIT" ||
                                    dataSet.Tables[0].Columns[j].Caption == "UAT" ||
                                    dataSet.Tables[0].Columns[j].Caption == "Prod") && data.Length > 0)
                                {
                                    writer.FindColumn(column.Remove(1)).Width = 12;
                                    DateTime dt = Convert.ToDateTime(Convert.ToDateTime(data).ToString("MM/dd/yyyy"));            
                                    writer.PasteDate(column, dt);                                 
                                }
                                else
                                    writer.PasteText(column, data);
                            }
                        }

                        SpreadsheetReader.RemoveWorksheetByName(doc, "Sheet2");
                        SpreadsheetReader.RemoveWorksheetByName(doc, "Sheet3");
                        //Save to the memory stream, and then to a file
                        SpreadsheetWriter.Save(doc);
                        SpreadsheetWriter.StreamToFile(string.Format("{0}MidrangeTaskList-QA_Meeting.xls", AppDomain.CurrentDomain.BaseDirectory), stream);


                        releaseObject(stream);
                        releaseObject(doc);
                        releaseObject(worksheetPart);
                        releaseObject(writer);
                    }
                    dataSet.Dispose();
                }
            }  
        }

        private static void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (ArgumentException)
            {
                obj = null;
            }
            finally
            {
                GC.Collect();
            }
        }

              

       

    }
}
