﻿using System;
using StatusBatch.SMTP;

namespace StatusBatch
{
    public class Email
    {
        public static void Send(string from, string to, string subject, string message)
        {
            try
            {
                SMTPWebService smtp = new SMTPWebService();
                //smtp.SMTPSendHTMLAsync(from, to, subject, message);
                smtp.SMTPSendHTML(from, to, subject, message);
            }
            catch (Exception ex)
            {
                System.Diagnostics.EventLog log = new System.Diagnostics.EventLog();
                log.WriteEntry(ex.Message, System.Diagnostics.EventLogEntryType.Error);
            }
        }
    }
}