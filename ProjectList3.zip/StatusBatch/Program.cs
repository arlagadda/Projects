﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StatusBatch
{
    class Program
    {
        private static string connectionStr = System.Configuration.ConfigurationManager.ConnectionStrings["DatabaseConnection"].ToString();
        static void Main(string[] args)
        {
            string isEmail = "Email";
            string toEmail = string.Empty;
            string FromEmail = ConfigurationManager.AppSettings["FromEmail"].ToString();
            string EmailSubject = ConfigurationManager.AppSettings["EmailSubject"].ToString();
            List<Resource> lstRes = new List<Resource>();
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "GetMissingStatus";
                        command.Parameters.AddWithValue("isEmail", isEmail);
                    
                        dataAdapter.SelectCommand = command;
                        DataSet dataSet = new DataSet();
                        dataAdapter.Fill(dataSet, "TableName");
                        foreach (var item in dataSet.Tables[0].AsEnumerable())
                        {
                            Resource obj = new Resource();
                            obj.Name = item["Name"].ToString();
                            obj.EmpID = item["EmpID"].ToString();

                            lstRes.Add(obj);
                        }

                        dataSet.Dispose();
                    }                    
                    connection.Close();
                }
            }
            List<string> lstName = new List<string>();

            if(lstRes.Count > 0)
            { 
                var dt = DateTime.Now.ToString("dd MMM yyyy");
                foreach(var item in lstRes)
                {
                    StringBuilder sbBody = new StringBuilder();
                    sbBody.Append("<br> <h2> "+ dt +" </h2>");
                    sbBody.Append("<br>");
                    sbBody.Append("Dear " + item.Name + " " + item.EmpID);
                    sbBody.Append("<br><br>");
                    sbBody.Append("<font color='red'><b> You are receiving this email because you have not submitted status report in TMT </b></font>");
                    sbBody.Append("<br><br>");
                    sbBody.Append("Going forward, please submit your status report on weekly basis before Friday of the week thru <a href='http://vwcapewctedw01.fisdev.local:8004/'> TMT </a> <br><br>");
                    sbBody.Append("Thanks, <br> Ramesh Tallada<br>");

                    toEmail = GetEmailId(item.EmpID);
                    lstName.Add(item.Name);
                    Email.Send(FromEmail, toEmail, EmailSubject, sbBody.ToString());
                }
            }

            SendStatusReport(lstName);


        }

        public class Resource
        {
            public string Name { get; set; }
            public string EmpID { get; set; }
        }

        static string GetEmailId(string empid)
        {
            string email = string.Empty;
            using (SqlConnection connection = new SqlConnection(connectionStr))
            {
                connection.Open();
                using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                {
                    using (SqlCommand command = connection.CreateCommand())
                    {
                        command.CommandType = CommandType.StoredProcedure;
                        command.CommandText = "GetEmailId";
                        command.Parameters.AddWithValue("empid", empid);

                        dataAdapter.SelectCommand = command;
                        DataSet dataSet = new DataSet();
                        dataAdapter.Fill(dataSet, "TableName");
                        foreach (var item in dataSet.Tables[0].AsEnumerable())
                        {
                            email = item["EMail"].ToString();
 
                        }
                    }
                }
            }

            return email;
        }

        static void SendStatusReport(List<string> names)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("List of resources not submitted Status Report in TMT. <br><br>");
            foreach(var item in names)
            {
                sb.Append("<ul><li>" + item.ToString() + "</li></ul>");
            }

            Email.Send("TMT@fisglobal.com", ConfigurationManager.AppSettings["ToEmail"].ToString(), "Status Report Not submitted resources.", sb.ToString());
        }
    }
}
