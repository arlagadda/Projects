BEGIN TRAN
SELECT ROW_NUMBER() OVER(PARTITION BY TaskID ORDER BY TaskID, AddedDate DESC) AS RowId, *  
INTO #MyTaskComments
FROM dbo.TaskComments

SELECT *  INTO #comments FROM #MyTaskComments WHERE RowId IN (1,2,3)


SELECT TaskID, comments = STUFF((
    SELECT ' ' + LEFT(CONVERT(VARCHAR, AddedDate, 101), 5) + ' - ' + comments + CHAR(13) + CHAR(10) + ' Newline '  FROM #comments
    WHERE TaskID = x.TaskID
    FOR XML PATH(''), TYPE).value('.[1]', 'nvarchar(max)'), 1, 2, '') INTO #CommentsTable
FROM #comments AS x
GROUP BY TaskID;

 select * from #CommentsTable 

 exec [dbo].[GetTaskListForReports] 'open'
 ROLLBACK TRAN