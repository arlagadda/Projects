select ResourceId,FirstName,* from Resource from Resource where ResourceId in(9,59)


select * from TaskDetails where Taskid = 6404 --[PPL#/I#/R#] ='PPL0052047'
--Taskid = 5866
select * from [dbo].[TaskBySchedule] where TaskId=6404 and Phase = 'UAT'
select TaskId,(select FirstName from Resource where ResourceId= T.ResourceId) as Name,
(select Phase from Phase where PhaseID = T.PhaseId) as Phase,Hours, FromDate, ToDate from [dbo].[TaskHours] T

select * from TaskHours 
select * from Phase



SELECT DATEDIFF(day,'10/16/2016','11/29/2016')

select Format(eomonth('10/16/2016'),'MM/dd/yyyy')

SELECT DATEDIFF(day,'10/16/2016',Format(eomonth('10/16/2016'),'MM/dd/yyyy'))

 select DATEPART(MONTH, GETDATE())
 declare @currentmonth int =1
 declare @month varchar(3)
  --select convert(char(3),DATENAME(MONTH, CONVERT(CHAR(1),@currentmonth) + '/1/1111'))

  select @month = convert(char(3),DATENAME(MONTH, CONVERT(CHAR(1),@currentmonth) + '/1/1111'))
  print @month
 select convert(char(3), '1/1/2222', 0)
 select substring(CONVERT(CHAR(4),DATEPART(yy, GETDATE())),3,2)

 DateName(mm,DATEADD(mm,1,0))
 exec ProjectResourceWiseHoursReport

 
 select * from ProjectHours

 drop table ProjectHours

 select count(*) from TaskHours where FromDate  > Format(DATEADD(D,1,EOMONTH(Getdate(),-2)),'MM/dd/yyyy')

 select GetDate() -1

 select FromDate from  TaskHours

 select DATEADD(m, -1, getdate())

 SELECT	DATEADD(MONTH, DATEDIFF(MONTH, '19000201', GETDATE()), '19000101') AS FirstPreviousMonth

 SELECT DATEADD(M, DATEDIFF(M, 0, GETDATE()), 0)

 select DATEDIFF(M, '19000201', GETDATE())

 SELECT DATEADD(M, -1, GETDATE()) AS FirstDay

 select Format(fomonth('10/16/2016'),'MM/dd/yyyy')

DECLARE @Date1 date
SET @Date1 = Format(Getdate(),'MM/dd/yyyy')
SELECT  EOMONTH(@Date1, -1)

select Format(DATEADD(D,1,EOMONTH(Getdate(),-2)),'MM/dd/yyyy')