﻿using BSEncrypt;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Services;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;

namespace SSOWebApplication
{
    public partial class SSOLaunchPage : System.Web.UI.Page
    {
        private static string encrptionKey = "SSOSVAPP";
        private static string connectionStr = "SSOSVConnection";     

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string authcode = Request.QueryString[0].ToString();
                //Add record into SSO_Login
                UserStatusInfo info = new UserStatusInfo();
                info.Authcode = authcode;
                info.Status = 0;
                Session["StatusInfo"] = info;
                AddStatus();
                ClientScript.RegisterStartupScript(this.GetType(), "Javascript", "GetAccessToken('" + authcode + "');", true);
            }
        }
       
        /// <summary>
        /// To add the message to local log file
        /// </summary>
        /// <param name="message">error message</param>
        protected static void WriteLogfile(string message)
        {
            StreamWriter log;
            string date = DateTime.Now.ToString("M-d-yyyy");
            if (!File.Exists(AppDomain.CurrentDomain.BaseDirectory + date + ".txt"))
            {
                log = new StreamWriter(AppDomain.CurrentDomain.BaseDirectory + date + ".txt");
            }
            else
            {
                log = File.AppendText(AppDomain.CurrentDomain.BaseDirectory + date + ".txt");
            }
            // Write to the file:
            log.WriteLine("--------------------" + DateTime.Now + "----------------------");
            log.WriteLine("Message: " + message);

            // Close the stream:
            log.Close();
        }

        /// <summary>
        ///  This mothod is used to decode the message and extract the MainframeId
        /// </summary>
        /// <param name="p">string</param>
        /// <returns>string</returns>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static string decodeText(string p)
        {
            string result = string.Empty;
            try
            {
                Base64Decoder decoder = new Base64Decoder(p.Split('.')[1].ToCharArray());
                string str2 = System.Text.Encoding.UTF8.GetString(decoder.GetDecoded());
                str2.Replace("{", "").Replace("}", "").Replace(@"\", "");
                foreach (string str in str2.Split(','))
                {
                    if (str.Split(':')[0].Contains("sub"))
                    {
                        result = str.Split(':')[1].Replace("\"", "");
                        break;
                    }
                }
                if (result != string.Empty)
                {
                    UpdateStatus(1, result, string.Empty);
                }
            }
            catch (Exception exp)
            {
                result = exp.Message;
                UpdateStatus(4, string.Empty, "Could not extract userid from ID Token " + exp.Message);

            }
            return result;
        }

        /// <summary>
        /// Method is to to get the decrypted Connectionstring.
        /// </summary>
        /// <param name="conName">Connection name</param>
        /// <returns>decrypted connection string</returns>
        private static string GetConnectionString(string conName)
        {
            BSSecurity encrypt = new BSSecurity();           

            return encrypt.DecryptString(ConfigurationManager.ConnectionStrings[conName].ToString(), encrptionKey);
        }

        /// <summary>
        ///  To add the SSO Login Status
        /// </summary>
        private static void AddStatus()
        {
            try
            {
                string connectionString = GetConnectionString(connectionStr);
                using (SqlConnection sqlconnection = new SqlConnection(connectionString))
                {
                    sqlconnection.Open();
                    using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                    {
                        using (SqlCommand command = sqlconnection.CreateCommand())
                        {
                            UserStatusInfo info = (UserStatusInfo)HttpContext.Current.Session["StatusInfo"];
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "AddSSOLogActivity";
                            command.Parameters.AddWithValue("@AuthorizationCode", info.Authcode);
                            command.Parameters.AddWithValue("@ClientID", ConfigurationManager.AppSettings["clientid"].ToString());
                            command.Parameters.AddWithValue("@ServerName", Dns.GetHostName());
                            command.ExecuteNonQuery();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLogfile(ex.ToString() + " -- occurred while trying to add status");
            }
        }

        /// <summary>
        /// To update the Status and Add LogMessage if error message
        /// </summary>
        /// <param name="newStatus">updated status</param>
        /// <param name="userid">UserId</param>
        /// <param name="errorText">Log message</param>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static string UpdateStatus(int newStatus, string userid, string errorText)
        {
            string result = string.Empty;
            try
            {
                string connectionString = GetConnectionString(connectionStr);
                using (SqlConnection sqlconnection = new SqlConnection(connectionString))
                {
                    sqlconnection.Open();
                    using (SqlDataAdapter dataAdapter = new SqlDataAdapter())
                    {
                        using (SqlCommand command = sqlconnection.CreateCommand())
                        {
                            UserStatusInfo info = (UserStatusInfo)HttpContext.Current.Session["StatusInfo"];
                            command.CommandType = CommandType.StoredProcedure;
                            command.CommandText = "UpdateSSOLogActivity";
                            if (userid.Trim().Length > 0)
                                command.Parameters.AddWithValue("@UserID", userid);
                            else
                                command.Parameters.AddWithValue("@UserID", DBNull.Value);
                            command.Parameters.AddWithValue("@AuthorizationCode", info.Authcode);
                            command.Parameters.AddWithValue("@OldStatus", info.Status);
                            command.Parameters.AddWithValue("@NewStatus", newStatus);
                            command.ExecuteNonQuery();
                        }
                    }
                }
                if (errorText.Trim().Length > 0)
                {
                    LogMessage(errorText);
                }
                result = "Success";
            }
            catch (Exception ex)
            {
                WriteLogfile(ex.ToString() + " -- occurred while trying to update status");
                result = "Error";
            }
            return result;
        }

        /// <summary>
        /// To add Log Message in to GLOG
        /// </summary>
        /// <param name="message">error message</param>
        private static void LogMessage(string message)
        {
            string result = string.Empty;
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(@"<?xml version=""1.0"" encoding=""utf-8""?>
                <soap:Envelope xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"" xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"">
                <soap:Body>
                <LogInfo xmlns=""http://fis.it.utility/EALService"">
                <ApplicationID>1100</ApplicationID>
                <LogSeverity>DEBUG</LogSeverity>
                <Message>" + message + "</Message><ServerName>Dev server</ServerName><AdditionalDatastring>Additional string</AdditionalDatastring></LogInfo></soap:Body></soap:Envelope>");

                HttpWebRequest req = (HttpWebRequest)WebRequest.Create(ConfigurationManager.AppSettings["GLOGSERVER"].ToString());
                req.ContentType = "text/xml;charset=\"utf-8\"";
                req.Accept = "text/xml";
                req.Method = "POST";

                using (Stream reqstm = req.GetRequestStream())
                {
                    doc.Save(reqstm);
                }

                using (WebResponse resp = req.GetResponse())
                {
                    using (Stream respstm = resp.GetResponseStream())
                    {
                        using (StreamReader r = new StreamReader(respstm))
                        {
                            result = r.ReadToEnd();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLogfile(ex.ToString() + " -- occurred while trying to log '" + message + "'");
            }
        }
    }

    /// <summary>
    /// Decoder class
    /// </summary>
    public class Base64Decoder
    {
        char[] source;
        int length, length2, length3;
        int blockCount;
        int paddingCount;
        public Base64Decoder(char[] input)
        {
            int temp = 0;
            source = input;
            length = input.Length;

            //find how many padding are there
            for (int x = 0; x < 2; x++)
            {
                if (input[length - x - 1] == '=')
                    temp++;
            }
            paddingCount = temp;
            // CALCULATEthe blockCount;
            //assuming all whitespace and carriage returns/newline were removed.
            blockCount = length / 4;
            length2 = blockCount * 3;
        }

        public byte[] GetDecoded()
        {
            byte[] buffer = new byte[length];//first conversion result
            byte[] buffer2 = new byte[length2];// DECODED ARRAYwith padding

            for (int x = 0; x < length; x++)
            {
                buffer[x] = char2sixbit(source[x]);
            }

            byte b, b1, b2, b3;
            byte temp1, temp2, temp3, temp4;

            for (int x = 0; x < blockCount; x++)
            {
                temp1 = buffer[x * 4];
                temp2 = buffer[x * 4 + 1];
                temp3 = buffer[x * 4 + 2];
                temp4 = buffer[x * 4 + 3];

                b = (byte)(temp1 << 2);
                b1 = (byte)((temp2 & 48) >> 4);
                b1 += b;

                b = (byte)((temp2 & 15) << 4);
                b2 = (byte)((temp3 & 60) >> 2);
                b2 += b;

                b = (byte)((temp3 & 3) << 6);
                b3 = temp4;
                b3 += b;

                buffer2[x * 3] = b1;
                buffer2[x * 3 + 1] = b2;
                buffer2[x * 3 + 2] = b3;
            }
            //remove paddings
            length3 = length2 - paddingCount;
            byte[] result = new byte[length3];

            for (int x = 0; x < length3; x++)
            {
                result[x] = buffer2[x];
            }

            return result;
        }

        private byte char2sixbit(char c)
        {
            char[] lookupTable = new char[64]
          {  

    'A','B','C','D','E','F','G','H','I','J','K','L','M','N',
    'O','P','Q','R','S','T','U','V','W','X','Y', 'Z',
    'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
    'o','p','q','r','s','t','u','v','w','x','y','z',
    '0','1','2','3','4','5','6','7','8','9','+','/'};
            if (c == '=')
                return 0;
            else
            {
                for (int x = 0; x < 64; x++)
                {
                    if (lookupTable[x] == c)
                        return (byte)x;
                }
                //should NOT REACH HERE
                return 0;
            }

        }

    }

    /// <summary>
    /// UserStatusInfo class with properties
    /// </summary>
    public class UserStatusInfo
    {
        private int status;
        private string authcode;
        public int Status
        {
            get
            {
                return status;
            }
            set
            {
                status = value;
            }
        }
        public string Authcode
        {
            get
            {
                return authcode;
            }
            set
            {
                authcode = value;
            }
        }
    }
}