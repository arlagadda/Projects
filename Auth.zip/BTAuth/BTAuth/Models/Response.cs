﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BTAuth.Models
{
    public class Response : Request
    {
        public string ResponseCode { get; set; }
        public string ResponseCodeMessage { get; set; }
        public string ApprovalCode { get; set; }
        public string Error { get; set; }

        public void CopyRequestInfo(Request authNetRequest)
        {
            if (authNetRequest != null)
            {
                this.AccountNumber = authNetRequest.AccountNumber;
                this.ExpireDate = authNetRequest.ExpireDate;
                this.Amount = authNetRequest.Amount;
                this.ProcessingType = authNetRequest.ProcessingType;
                this.PostingBucket = authNetRequest.PostingBucket;
            }
        }
    }
}