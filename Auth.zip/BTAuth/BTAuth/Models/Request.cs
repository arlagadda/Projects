﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BTAuth.Models
{
    public class Request
    {
        public string AccountNumber { get; set; }
        public string Amount { get; set; }
        public string ExpireDate { get; set; }
        public string ProcessingType { get; set; }
        public string PostingBucket { get; set; }
    }
}