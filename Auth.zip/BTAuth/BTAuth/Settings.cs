﻿using BTAuth.Constants;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BTAuth
{
    public static class Settings
    {
        static Settings()
        {
            PrimaryQManager = Utility.GetAppSetting<String>(AppConstants.PRIMARY_Q_MANAGER_NAME, "");
            SecondaryQManager = Utility.GetAppSetting<String>(AppConstants.SECONDARY_Q_MANAGER_NAME, "");
            GetQName = Utility.GetAppSetting<String>(AppConstants.AUTH_GET_Q_NAME, "");
            PutQName = Utility.GetAppSetting<String>(AppConstants.AUTH_PUT_Q_NAME, "");
            QTimeout = Utility.GetAppSetting<int>(AppConstants.AUTH_Q_TIMEOUT, AppConstants.DEFAULT_Q_TIMEOUT);
            OperatorID = Utility.GetAppSetting<string>(AppConstants.OPERATOR_ID, AppConstants.DEFAULT_OPERATOR_ID);
            CashMerchantID = Utility.GetAppSetting<string>(AppConstants.MERCHANT_ID_CASH, AppConstants.DEFAULT_MERCHANT_ID_CASH);
            PurchaseMerchantID = Utility.GetAppSetting<string>(AppConstants.MERCHANT_ID_PURCHASE, AppConstants.DEFAULT_MERCHANT_ID_PURCHASE);
            TranCode = Utility.GetAppSetting<string>(AppConstants.TRANSACTION_CODE, AppConstants.DEFAULT_TRANSACTION_CODE);
            LogDetails = Utility.GetAppSetting<bool>(AppConstants.LOG_DETAILS, false);
            SMTPFrom = Utility.GetAppSetting<string>(AppConstants.SMTP_FROM, AppConstants.DEFAULT_SMTP_FROM);
            AuthToList = Utility.GetAppSetting<string>(AppConstants.AUTH_TO_LIST, AppConstants.DEFAULT_AUTH_TO_LIST);
            AuthCCList = Utility.GetAppSetting<string>(AppConstants.AUTH_CC_LIST, "");
        }

        public static string PrimaryQManager { get; private set; }
        public static string SecondaryQManager { get; private set; }
        public static string GetQName { get; private set; }
        public static string PutQName { get; private set; }
        public static int QTimeout { get; private set; }
        public static string OperatorID { get; private set; }
        public static string CashMerchantID { get; private set; }
        public static string PurchaseMerchantID { get; private set; }
        public static string TranCode { get; private set; }
        public static bool LogDetails { get; private set; }
        public static string AuthToList { get; private set; }
        public static string AuthCCList { get; private set; }
        public static string SMTPFrom { get; private set; }
    }
}