﻿using System.Collections.Specialized;
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Configuration;
using System.Web;
using System.Text;
using System.Data.SqlClient;
using System.Xml;
using BTAuth.EALService;
using BSEncrypt = IT.Component.BSSecurity;
using BTAuth.Constants;
using System.Linq;
using BTAuth.Extensions;
using BTAuth.Models;
using VBConstants = Microsoft.VisualBasic.Constants;

namespace BTAuth
{
    public class Auth : IHttpHandler, IDisposable
    {
        #region Implements IHttpHandler

        public bool IsReusable
        {

            get { return false; }
        }

        public void ProcessRequest(HttpContext context)
        {
            string responseXML = string.Empty;
            string requestParams = string.Empty;
            string accountNumber = string.Empty;
            string mqRequestMessage = string.Empty;
            string mqResponseMessage = string.Empty;
            string error = string.Empty;

            try
            {
                requestParams = GetRequestParams(context);
                string requestXML = context.Request["AUTHXML"];

                if (requestXML != null)
                {
                    var request = ParseRequestXML(requestXML);
                    accountNumber = request.AccountNumber;

                    // parse out the variables we need
                    if (request != null)
                    {
                        mqRequestMessage = mqResponseMessage = CreateMQRequest(request);
                        if (Settings.LogDetails)
                        {
                            Utility.LogMessage("Message To AuthNet: "
                                + Utility.MaskLoggingInfo(mqRequestMessage, AppConstants.AUTH_NET_ACCOUNT_NUMBER, 10, 6));
                        }

                        // send and receive authnet message
                        mqResponseMessage = GetResponseFromMQ(mqRequestMessage);
                        if (Settings.LogDetails)
                        {
                            Utility.LogMessage("Message From AuthNet: "
                                + Utility.MaskLoggingInfo(mqResponseMessage, AppConstants.AUTH_NET_ACCOUNT_NUMBER, 10, 6));
                        }

                        // parse the authnet message
                        var response = ParseMQResponse(mqResponseMessage);
                        response.CopyRequestInfo(request);
                        if (Settings.LogDetails)
                            Utility.LogMessage("Authnet message Parsed Successfully");

                        responseXML = CreateResponseXML(response);
                    }
                }
            }
            catch (Exception ex)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("Error String:" + VBConstants.vbCrLf + ex.ToString() + VBConstants.vbCrLf);
                sb.Append("Error Message:" + VBConstants.vbCrLf + ex.Message + VBConstants.vbCrLf);
                sb.Append("Error Source:" + VBConstants.vbCrLf + ex.Source + VBConstants.vbCrLf);
                error = sb.ToString();

                Utility.LogMessage(error, true);

                //create empty response xml
                var response = new Response()
                {
                    Error = ex.Message
                };
                responseXML = CreateResponseXML(response);

                Utility.SendSMTP(Settings.AuthToList,
                    Settings.AuthCCList, "Error In BTAuth HTTPHandler", response.Error, Settings.SMTPFrom);
            }

            UpdateDatabase(accountNumber, requestParams
                , mqRequestMessage, mqResponseMessage, responseXML, error);

            // buffer the output and clear anything we have right now
            // we will flush buffer with the response.end statement
            context.Response.BufferOutput = true;
            context.Response.ClearContent();
            context.Response.ClearHeaders();
            context.Response.Write(responseXML);
            context.Response.End();
        }

        #endregion

        #region Implements IDisposable

        public void Dispose()
        {
        }

        #endregion

        #region Private, Helper Methods

        private string CreateMQRequest(Request request)
        {
            // this function will take the variables parsed out of the incoming xml and return an Authnet message
            // of field value pairs.
            // Authnet messages consist of the field name - sep - field len - sep - field value

            StringBuilder sb = new StringBuilder();

            if (request == null)
                return sb.ToString();

            // account number
            sb.Append(AppConstants.AUTH_NET_ACCOUNT_NUMBER
                + AppConstants.AUTH_NET_SEP + request.AccountNumber.Length.ToString()
                + AppConstants.AUTH_NET_SEP + request.AccountNumber
                + AppConstants.AUTH_NET_SEP);

            // exp date comes in as MMYY, Authnet wants YYMM
            if (request.ExpireDate.Length >= 4)
            {
                sb.Append(AppConstants.AUTH_NET_EXPIRE_DATE
                    + AppConstants.AUTH_NET_SEP + request.ExpireDate.Length.ToString()
                    + AppConstants.AUTH_NET_SEP + request.ExpireDate.Substring(2, 2) + request.ExpireDate.Substring(0, 2)
                    + AppConstants.AUTH_NET_SEP);
            }

            // add on merchant id, operarot id, and preauth amount
            switch (request.ProcessingType)
            {
                case AppConstants.PROCESSING_TYPE_CASH:
                    sb.Append(AppConstants.AUTH_NET_MERCHANT_ID
                        + AppConstants.AUTH_NET_SEP + Settings.CashMerchantID.Length.ToString()
                        + AppConstants.AUTH_NET_SEP + Settings.CashMerchantID
                        + AppConstants.AUTH_NET_SEP);
                    break;
                case AppConstants.PROCESSING_TYPE_PURCHASE:
                    sb.Append(AppConstants.AUTH_NET_MERCHANT_ID
                        + AppConstants.AUTH_NET_SEP + Settings.PurchaseMerchantID.Length.ToString()
                        + AppConstants.AUTH_NET_SEP + Settings.PurchaseMerchantID
                        + AppConstants.AUTH_NET_SEP);
                    break;
                default:
                    sb.Append(AppConstants.AUTH_NET_MERCHANT_ID
                        + AppConstants.AUTH_NET_SEP + Settings.PurchaseMerchantID.Length.ToString()
                        + AppConstants.AUTH_NET_SEP + Settings.PurchaseMerchantID
                        + AppConstants.AUTH_NET_SEP);
                    break;
            }

            sb.Append(AppConstants.AUTH_NET_OPERATOR_ID
                + AppConstants.AUTH_NET_SEP + Settings.OperatorID.Length.ToString()
                + AppConstants.AUTH_NET_SEP + Settings.OperatorID
                + AppConstants.AUTH_NET_SEP);

            sb.Append(AppConstants.AUTH_NET_TRANSACTION_AMOUNT
                + AppConstants.AUTH_NET_SEP + request.Amount.Length.ToString()
                + AppConstants.AUTH_NET_SEP + request.Amount.Trim()
                + AppConstants.AUTH_NET_SEP);

            sb.Append(AppConstants.AUTH_NET_TRANSACTION_CODE
                + AppConstants.AUTH_NET_SEP + Settings.TranCode.Length.ToString()
                + AppConstants.AUTH_NET_SEP + Settings.TranCode);

            return sb.ToString();
        }

        private string CreateResponseXML(Response response)
        {
            StringBuilder sb = new StringBuilder();

            if (response == null)
                return sb.ToString();

            sb.Append("<?xml version=\"1.0\"?>");

            sb.Append("<" + AppConstants.XML_AUTHOUT + ">");

            sb.Append("<" + AppConstants.XML_ACCOUNT_NUMBER + ">");
            sb.Append(response.AccountNumber ?? string.Empty);
            sb.Append("</" + AppConstants.XML_ACCOUNT_NUMBER + ">");

            sb.Append("<" + AppConstants.XML_EXPIRE_DATE + ">");
            sb.Append(response.ExpireDate ?? string.Empty);
            sb.Append("</" + AppConstants.XML_EXPIRE_DATE + ">");

            sb.Append("<" + AppConstants.XML_AMOUNT + ">");
            sb.Append(response.Amount ?? string.Empty);
            sb.Append("</" + AppConstants.XML_AMOUNT + ">");

            sb.Append("<" + AppConstants.XML_PROCESSING_TYPE + ">");
            sb.Append(response.ProcessingType ?? string.Empty);
            sb.Append("</" + AppConstants.XML_PROCESSING_TYPE + ">");

            sb.Append("<" + AppConstants.XML_POSTING_BUCKET + ">");
            sb.Append(response.PostingBucket ?? string.Empty);
            sb.Append("</" + AppConstants.XML_POSTING_BUCKET + ">");

            sb.Append("<" + AppConstants.XML_RESPONSE_CODE + ">");
            sb.Append(response.ResponseCode ?? string.Empty);
            sb.Append("</" + AppConstants.XML_RESPONSE_CODE + ">");

            sb.Append("<" + AppConstants.XML_RESPONSE_CODE_MESSAGE + ">");
            sb.Append(response.ResponseCodeMessage ?? string.Empty);
            sb.Append("</" + AppConstants.XML_RESPONSE_CODE_MESSAGE + ">");

            sb.Append("<" + AppConstants.XML_APPROVAL_CODE + ">");
            sb.Append(response.ApprovalCode ?? string.Empty);
            sb.Append("</" + AppConstants.XML_APPROVAL_CODE + ">");

            sb.Append("<" + AppConstants.XML_ERROR + ">");
            sb.Append(response.Error ?? string.Empty);
            sb.Append("</" + AppConstants.XML_ERROR + ">");

            sb.Append("</" + AppConstants.XML_AUTHOUT + ">");

            return sb.ToString();
        }

        private string GetRequestParams(HttpContext context)
        {
            string requestParams = string.Empty;

            if (Settings.LogDetails)
                Utility.LogMessage("Number of values in querystring: " + context.Request.QueryString.Keys.Count.ToString());

            requestParams = GetRequestParams(context.Request.QueryString);

            if (context.Request.QueryString.Count == 0)
            {
                if (Settings.LogDetails)
                    Utility.LogMessage("Number of values in form: " + context.Request.Form.Count.ToString());

                requestParams = GetRequestParams(context.Request.Form);
            }

            return requestParams;
        }

        private string GetRequestParams(NameValueCollection nameValueCollection)
        {
            var requestParams = new StringBuilder();

            if (nameValueCollection != null)
            {
                for (int i = 0; i <= nameValueCollection.Count - 1; i++)
                {
                    requestParams.Append(nameValueCollection.Keys[i] + ": "
                        + Utility.MaskLoggingInfo(nameValueCollection[i], AppConstants.XML_AUTHIN, AppConstants.XML_ACCOUNT_NUMBER, 6, 6)
                        + Microsoft.VisualBasic.Constants.vbCrLf);

                    if (Settings.LogDetails)
                    {
                        Utility.LogMessage("Field Name: " + nameValueCollection.Keys[i]
                            + "="
                            + Utility.MaskLoggingInfo(nameValueCollection[i], AppConstants.XML_AUTHIN, AppConstants.XML_ACCOUNT_NUMBER, 6, 6).ToUpper());
                    }
                }
            }

            return requestParams.ToString();
        }

        private string GetResponseFromMQ(string requestMessage)
        {
            string responseMessage = string.Empty;

            using (var mqTrans = new NetMQPutGet.NetMQTrans(Settings.PrimaryQManager, Settings.SecondaryQManager,
                Settings.PutQName, Settings.GetQName, Settings.QTimeout))
            {
                // send and receive message
                if (!mqTrans.MQTransPutGet(requestMessage, ref responseMessage))
                    throw new Exception("MQTrans Returned False In SendToAuthNet");
            }

            return responseMessage.Trim().TrimEnd(Strings.Chr(0));
        }

        private Response ParseMQResponse(string mqResponseMessage)
        {
            //e.g.
            //account_numberº16º4604450011967659ºexpiration_dateº4º1604ºmerchant_idº9º804360287ºoperatoridº3º000ºtran_amtº2º10ºtransaction_codeº3º100
            //format : <field>º<value-length>º<value>
            // this function will parse the authnet string, returning dictionary of key value
            Response response = new Response();

            var array = mqResponseMessage.Split('º');

            var keys = array
                .Where((p, q) => q % 3 == 0)
                .Select((Value, Index) => new { Value, Index });

            var values = array
                .Where((p, q) => (q + 1) % 3 == 0)
                .Select((Value, Index) => new { Value, Index });

            foreach (var key in keys)
            {
                var value = values.First(p => p.Index == key.Index);

                if (value != null)
                {
                    switch (key.Value)
                    {
                        case AppConstants.AUTH_NET_APPROVAL_CODE:
                            response.ApprovalCode = value.Value;
                            break;
                        case AppConstants.AUTH_NET_INCOMING_RESPONSE_CODE:
                            response.ResponseCode = value.Value;
                            break;
                        case AppConstants.AUTH_NET_RESPONSE_CODE_MESSAGE:
                            response.ResponseCodeMessage = value.Value;
                            break;
                    }
                }
            }

            return response;
        }

        private Request ParseRequestXML(string requestXML)
        {
            XmlDocument oDom = new XmlDocument();
            oDom.LoadXml(requestXML);

            if (oDom.GetElementsByTagName(AppConstants.XML_AUTHIN).Count > 0)
            {
                return new Request()
                {
                    AccountNumber = oDom[AppConstants.XML_AUTHIN][AppConstants.XML_ACCOUNT_NUMBER].InnerText.Trim(),
                    ExpireDate = oDom[AppConstants.XML_AUTHIN][AppConstants.XML_EXPIRE_DATE].InnerText.Trim(),
                    Amount = oDom[AppConstants.XML_AUTHIN][AppConstants.XML_AMOUNT].InnerText.Trim().Replace(".", ""),
                    ProcessingType = oDom[AppConstants.XML_AUTHIN][AppConstants.XML_PROCESSING_TYPE].InnerText.Trim().ToUpper(),
                    PostingBucket = oDom[AppConstants.XML_AUTHIN][AppConstants.XML_POSTING_BUCKET].InnerText.Trim()
                };
            }

            return null;
        }

        private void UpdateDatabase(string accountNumber, string requestParams
            , string mqRequestMessage, string mqResponseMessage, string responseXML, string error)
        {
            var connString = Utility.GetConnectionString();
            var authStoredProc = Utility.GetAppSetting<string>("AUTH_STORED_PROCEDURE", "");

            if (!string.IsNullOrEmpty(connString) && !string.IsNullOrEmpty(authStoredProc))
            {
                using (var conn = new SqlConnection(connString))
                {
                    try
                    {
                        conn.Open();

                        var cmd = new SqlCommand(authStoredProc, conn);
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@account_num", SqlDbType.VarChar, AppConstants.MAX_DB_ACCT_SIZE).Value
                            = Utility.MaskLoggingInfo(accountNumber, 6, 6);
                        cmd.Parameters.Add("@name_val", SqlDbType.VarChar, AppConstants.MAX_DB_MSG_SIZE).Value
                            = requestParams;
                        cmd.Parameters.Add("@msg_to_authnet", SqlDbType.VarChar, AppConstants.MAX_DB_MSG_SIZE).Value
                            = Utility.MaskLoggingInfo(mqRequestMessage, AppConstants.AUTH_NET_ACCOUNT_NUMBER, 10, 6);
                        cmd.Parameters.Add("@msg_from_authnet", SqlDbType.VarChar, AppConstants.MAX_DB_MSG_SIZE).Value
                            = Utility.MaskLoggingInfo(mqResponseMessage, AppConstants.AUTH_NET_ACCOUNT_NUMBER, 10, 6);
                        cmd.Parameters.Add("@resp_msg", SqlDbType.VarChar, AppConstants.MAX_DB_MSG_SIZE).Value
                            = Utility.MaskLoggingInfo(responseXML, AppConstants.XML_AUTHOUT, AppConstants.XML_ACCOUNT_NUMBER, 6, 6);
                        cmd.Parameters.Add("@error_msg", SqlDbType.VarChar, AppConstants.MAX_DB_MSG_SIZE).Value = error;

                        cmd.ExecuteNonQuery();
                    }
                    catch (Exception ex)
                    {
                        Utility.LogMessage("Error Logging To Database: " + ex.Message, false);
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
        }

        #endregion
    }
}