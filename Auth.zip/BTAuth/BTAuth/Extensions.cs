﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace BTAuth.Extensions
{
    public static class Extensions
    {
        public static TValue GetValue<TKey, TValue>(this IEnumerable<KeyValuePair<TKey, TValue>> pairs, TKey key)
        {
            TValue value = default(TValue);

            var pair = pairs.First(p => p.Key.Equals(key));
            if (!default(KeyValuePair<string, string>).Equals(pair))
                value = pair.Value;

            return value;
        }

        public static IEnumerable<KeyValuePair<string, string>> GetElements(this string xml, string xPath)
        {
            try
            {
                if (!string.IsNullOrEmpty(xml))
                {
                    XmlDocument xDoc = new XmlDocument();
                    xDoc.LoadXml(xml);

                    return xDoc.SelectNodes(xPath)
                        .Cast<XmlNode>()
                        .Select(p => new KeyValuePair<string, string>(p.Name, p.InnerText));
                }
            }
            catch (XmlException)
            {
                throw;
            }

            return new List<KeyValuePair<string, string>>();
        }

        public static string ToStringWithDeclaration(this XDocument xDoc)
        {
            if (xDoc == null)
            {
                throw new ArgumentNullException("doc");
            }

            StringBuilder builder = new StringBuilder();

            using (TextWriter writer = new StringWriter(builder))
            {
                xDoc.Save(writer);
            }

            return builder.ToString();
        }
    }
}