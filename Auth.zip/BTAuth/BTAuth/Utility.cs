﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Xml;
using BTAuth.SMTP;
using System.Text;
using System.Configuration;
using IT.Component;
using BTAuth.Constants;

namespace BTAuth
{
    public static class Utility
    {
        public static void SendSMTP(string strTOList, string strCCList, string strSubject, string strMessage, string strSMTPFrom)
        {
            // this sub will send an smtp message

            BTAuth.SMTP.SMTPWebService oMail = null;
            string From = null;
            StringBuilder toRecip = default(StringBuilder);

            try
            {
                if (strTOList.Trim().Length > 0)
                {
                    oMail = new BTAuth.SMTP.SMTPWebService();

                    From = strSMTPFrom.Trim().ToString();

                    toRecip = new StringBuilder();
                    foreach (string address in strTOList.Trim().Split(char.Parse(";")))
                    {
                        toRecip.Append(address + ";");
                    }

                    if (strCCList.Trim().Length > 0)
                    {
                        foreach (string address in strCCList.Trim().Split(char.Parse(";")))
                        {
                            toRecip.Append(address + ";");
                        }
                    }

                    oMail.SMTPSend(From, toRecip.ToString(), strSubject.Trim(), strMessage.Trim());
                }
            }
            catch
            {
            }
            finally
            {
                if (oMail != null)
                    oMail.Dispose();

            }
        }

        public static string MaskLoggingInfo(String DataToBeMasked, int StartPosition, int LengthOfMask)
        {
            // replace the data with X's for logging purposes

            if (DataToBeMasked.Length >= StartPosition + 1 + LengthOfMask)
            {
                var oldValue = Strings.Mid(DataToBeMasked, StartPosition + 1, LengthOfMask);
                var newValue = "X".PadRight(LengthOfMask, 'X');

                return DataToBeMasked.Replace(oldValue, newValue);
            }

            return DataToBeMasked;
        }

        public static string MaskLoggingInfo(string XMLDoc, string PrimaryXMLNodeName, string XMLNodeName, int StartPosition, int LengthOfMask)
        {

            XmlDocument doc = new XmlDocument();
            XmlNode ReplaceNode = default(XmlNode);

            try
            {
                doc.LoadXml(XMLDoc);
                ReplaceNode = doc.SelectSingleNode(PrimaryXMLNodeName).SelectSingleNode(XMLNodeName);
                if (ReplaceNode == null)
                {
                    return XMLDoc.ToString();
                }
                ReplaceNode.InnerText = MaskLoggingInfo(ReplaceNode.InnerText, StartPosition, LengthOfMask);
                return (doc.OuterXml.ToString());
            }
            catch (Exception)
            {
                return XMLDoc.ToString();
            }
            finally
            {
                doc = null;
            }

        }

        public static string MaskLoggingInfo(string DataToBeMasked, string InDataString, int AddPostions, int LengthOfMask)
        {
            // replace the data with X's for logging purposes

            int Found = DataToBeMasked.IndexOf(InDataString);

            if (Found < 0)
            {
                return DataToBeMasked;
            }

            if (DataToBeMasked.Length >= InDataString.Length + AddPostions + 1 + Found + LengthOfMask)
            {
                var oldValue = Strings.Mid(DataToBeMasked, InDataString.Length + Found + AddPostions + 1, LengthOfMask);
                var newValue = "X".PadRight(LengthOfMask, 'X');

                return DataToBeMasked.Replace(oldValue, newValue);
            }
            else
            {
                return DataToBeMasked;
            }

        }

        public static void LogMessage(string message, bool isError = false)
        {
            var appName = Utility.GetAppSetting<string>(AppConstants.APP_NAME, AppConstants.DEFAULT_APP_NAME);
            var appNumber = Utility.GetAppSetting<int>(AppConstants.APP_NUMBER, 0);
            var serverName = Utility.GetAppSetting<string>(AppConstants.SERVER_NAME, "UNKNOWN; NEEDS TO BE SET");

            LogMessage(appName, appNumber, serverName, message, isError);
        }

        public static string GetConnectionString()
        {
            BSSecurity oSecurity = new BSSecurity();

            var connectionString = GetAppSetting<string>(AppConstants.LOG_DB_CONNECTION_STRING, "");

            return oSecurity.DecryptString(connectionString, "btauth");
        }

        public static T GetAppSetting<T>(string key, T defaultValue)
        {
            try
            {
                if (string.IsNullOrEmpty(key))
                    throw new KeyNotFoundException(key + " Not Found, Please Check the Configuration");

                var value = ConfigurationManager.AppSettings.Get(key);
                if (string.IsNullOrEmpty(value.Trim()))
                    return defaultValue;

                return (T)Convert.ChangeType(value.Trim(), typeof(T));
            }
            catch (KeyNotFoundException ex)
            {
                Utility.LogMessage(ex.Message, true);
            }

            return default(T);
        }

        private static void LogMessage(string appName, int appNumber, string serverName, string message, bool isError)
        {
            using (var ealService = new EALService.EALService())
            {
                try
                {
                    EALService.SEVERITY severity = isError
                        ? EALService.SEVERITY.ERROR
                        : EALService.SEVERITY.INFO;

                    ealService.LogInfo(appNumber, severity, message, serverName, string.Empty);
                }
                catch (Exception ex)
                {
                    using (var log = new EventLog())
                    {
                        log.Source = appName;
                        log.Log = "Application";
                        log.WriteEntry(message + "\\n\\nProblem with FIS_EAL: " + ex.ToString());
                    }
                }
            }
        }
    }
}