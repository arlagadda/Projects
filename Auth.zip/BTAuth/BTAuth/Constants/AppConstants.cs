﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BTAuth.Constants
{
    public static class AppConstants
    {
        //AppSetting Keys
        public const string PRIMARY_Q_MANAGER_NAME = "PRIMARY_Q_MANAGER_NAME";
        public const string SECONDARY_Q_MANAGER_NAME = "SECONDARY_Q_MANAGER_NAME";
        public const string AUTH_GET_Q_NAME = "AUTH_GET_Q_NAME";
        public const string AUTH_PUT_Q_NAME = "AUTH_PUT_Q_NAME";
        public const string AUTH_Q_TIMEOUT = "AUTH_Q_TIMEOUT";
        public const string OPERATOR_ID = "OPERATOR_ID";
        public const string MERCHANT_ID_CASH = "MERCHANT_ID_CASH";
        public const string MERCHANT_ID_PURCHASE = "MERCHANT_ID_PURCHASE";
        public const string TRANSACTION_CODE = "TRANSACTION_CODE";
        public const string LOG_DETAILS = "LOG_DETAILS";
        public const string APP_NAME = "APP_NAME";
        public const string APP_NUMBER = "APP_NUMBER";
        public const string SERVER_NAME = "SERVER_NAME";
        public const string SMTP_FROM = "SMTP_FROM";
        public const string AUTH_TO_LIST = "AUTH_TO_LIST";
        public const string AUTH_CC_LIST = "AUTH_CC_LIST";
        public const string LOG_DB_CONNECTION_STRING = "LOG_DB_CONNECTION_STRING";
        public const string AUTH_STORED_PROCEDURE = "AUTH_STORED_PROCEDURE";

        //AppSettings Default Values
        public const string DEFAULT_OPERATOR_ID = "000";
        public const string DEFAULT_MERCHANT_ID_CASH = "999999999";
        public const string DEFAULT_MERCHANT_ID_PURCHASE = "999999999";
        public const string DEFAULT_TRANSACTION_CODE = "100";
        public const string DEFAULT_AUTH_TO_LIST = "BusinessSolutions@fisglobal.com";
        public const string DEFAULT_SMTP_FROM = "BusinessSolutions@fisglobal.com";
        public const int DEFAULT_Q_TIMEOUT = 30000;
        public const string DEFAULT_APP_NAME = "Balance Transfer Authorization";

        //xml constants
        public const string XML_RESPONSE_CODE_MESSAGE = "RESPONSECODEMESSAGE";
        public const string XML_ACCOUNT_NUMBER = "ACCOUNTNUMBER";
        public const string XML_EXPIRE_DATE = "EXPDATE";
        public const string XML_AMOUNT = "AMOUNT";
        public const string XML_PROCESSING_TYPE = "PROCESSINGTYPE";
        public const string XML_POSTING_BUCKET = "POSTINGBUCKET";
        public const string XML_RESPONSE_CODE = "RESPONSECODE";
        public const string XML_APPROVAL_CODE = "APPROVALCODE";
        public const string XML_ERROR = "ERROR";
        public const string XML_AUTHIN = "AUTHIN";
        public const string XML_AUTHOUT = "AUTHOUT";
        public const string AUTH_PRIMARY_XMLNODENAME = "AUTHIN";
        public const string AUTH_ACCOUNTNUMBER_XMLNODENAME = "ACCOUNTNUMBER";
        public const string AUTHOUT_PRIMARY_XMLNODENAME = "AUTHOUT";

        // processing types
        public const string PROCESSING_TYPE_CASH = "C";
        public const string PROCESSING_TYPE_PURCHASE = "P";

        // authnet constants
        public const string AUTH_NET_SEP = "º"; //chr(186)
        public const string AUTH_NET_ACCOUNT_NUMBER = "account_number";
        public const string AUTH_NET_EXPIRE_DATE = "expiration_date";
        public const string AUTH_NET_TRANSACTION_AMOUNT = "tran_amt";
        public const string AUTH_NET_INCOMING_RESPONSE_CODE = "incoming_response_code";
        public const string AUTH_NET_RESPONSE_CODE_MESSAGE = "response_code_message";
        public const string AUTH_NET_APPROVAL_CODE = "approval_code";
        public const string AUTH_NET_OPERATOR_ID = "operatorid";
        public const string AUTH_NET_TRANSACTION_CODE = "transaction_code";
        public const string AUTH_NET_MERCHANT_ID = "merchant_id";

        //db constants
        public const int MAX_DB_MSG_SIZE = 500;
        public const int MAX_DB_ACCT_SIZE = 19;
    }
}